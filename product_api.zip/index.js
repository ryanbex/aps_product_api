'use strict';
var Product = require('./product');
/* endpoints
https://www.allpoolspa.com/api/v1/product/asin/{sku}
https://www.allpoolspa.com/api/v1/product/asins/{sku}
https://www.allpoolspa.com/api/v1/product/upc/{sku}
https://www.allpoolspa.com/api/v1/product/cost/{sku}
https://www.allpoolspa.com/api/v1/product/costs/{sku}
https://www.allpoolspa.com/api/v1/products/
https://www.allpoolspa.com/api/v1/products/?q={[minPrice, maxPrice, manufacturer]}
*/
var mongoose = require('mongoose');
mongoose.connect('mongodb://ryanDev:p8r8g0n@ds011913.mlab.com:11913/allpoolspa/catalog');

exports.handler = (event, context, callback) => {
    
    //conn.on('error', callback);
    //console.log('Received event:', JSON.stringify(event, null, 2));
    const operation = event.operation;
    console.log(Product);
    //response = Product.asin(event.sku);
    //callback(Product.asin(event.sku));
    callback(null, "Hello");


};